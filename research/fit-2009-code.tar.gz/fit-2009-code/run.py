#!/usr/bin/python -W ignore::DeprecationWarning

import test1
import IR
from var import *
from util import *

from pprint import *
import networkx as nx
import matplotlib.pyplot as plt
import subprocess
import pygraphviz
import sys
import copy
import atexit




class BB:
	def __init__ (self, cfg, name, stmts):
		self.cfg = cfg;
		self.name = name
		self.stmts = stmts;
		for stmt in stmts:
			stmt.bb = self

		self.doms = set()
		self.idoms = set()
		self.phis = {}
		self.df = set()

	
	def in_degree (self):
		return self.cfg.G.in_degree (self.name)

	def preds (self):
		return map (lambda pred: self.cfg.bbs[pred], self.cfg.G.predecessors (self.name))

	def succs (self):
		return map (lambda succ: self.cfg.bbs[succ], self.cfg.G.successors (self.name))

	def get_immediate_dominator (self):
		if len (self.idoms) == 0:
			return None
		return self.idoms[0]



	def is_dominated_by (self, bb):
		assert bb.__class__ == BB
		runner = self
		while runner != None:
			if runner == bb:
				return True

			runner = runner.get_immediate_dominator ()

		return False



	def has_phi (self, varname):

		for stmt in self.stmts:
			if isinstance (stmt, IR.Phi):
				if stmt.lhs.name == varname:
					return True

		return False


	# This should be __str__, but %s doesnt make that happen, for some reason.
	def __repr__ (self):
#		return "%s-0x%x" % (self.name, id (self))
		return str (self.name)



class CFG:

	dot_string = ""

	def __init__ (self, vars, bbs):
		self.init_vars (vars)
		self.build_graph (bbs)
		self.build_dominance ()

		self.execution_clients = []


	def init_vars (self, vars):
		self.vars = {}
		for name in vars:
			self.vars[name] = Var(name)

	def dump_all_vars (self):

		def varcmp (v1, v2):
			result = cmp(v1.name, v2.name)
			if result == 0:
				result = cmp (v1.version, v2.version)
			return result

		defs = []
		uses = []
		for bb in self.get_bbs ():
			for stmt in bb.stmts:
				defs += stmt.get_defs ()
				uses += stmt.get_uses ()


		defs.sort (cmp=varcmp)
		uses = list (uses)
		uses.sort (cmp=varcmp)
		print "defs: " + str (defs)
		print "uses: " + str (uses)



	def build_graph (self, bbs):

		self.bbs = {}
		for name, stmts in bbs.iteritems ():
			self.bbs[name] = BB (self, name, stmts)

		self.G = nx.DiGraph()

		# Put all the edges in the graph
		for bb in self.get_bbs ():
			if len (bb.stmts):
				final = bb.stmts[-1]
				for succ_name in final.get_successor_names ():
					self.G.add_edge (bb.name, succ_name)


	def get_bbs (self):
		return self.bbs.values ()

	def get_entry (self):
		return self.bbs["entry"]

	def get_exit (self):
		return self.bbs["exit"]




	def dump_cfg (self, title, current_bb):

		A = nx.to_agraph (self.G)

		# Add title
		A.graph_attr["label"] = title

		# Add BB labels
		for bb in self.get_bbs():

			rep = "BB_%s" % bb.name

			for stmt in bb.stmts:
				if stmt.__class__ != IR.Goto:
					rep += "\\n" + str (stmt)

			A.get_node (bb).attr["label"] = rep


		# Make the worklist visible (redder means sooner)
		length = float (len (self.cfg_wl))
		for i in xrange (length):
			reddish = 255 - (127 * (i / length))
			other = 255 - reddish
			color = "#%2x%2x%2x" % (reddish, other, other)

			bb = self.cfg_wl[i]
			A.get_node (bb).attr["fillcolor"] = color
			A.get_node (bb).attr["style"] = "filled"

		# Make the current BB visible
		A.get_node (current_bb).attr["shape"] = "tripleoctagon"
		A.get_node (current_bb).attr["color"] = "blue"
			
		CFG.dot_string += A.string ()



	def dump_saved_dot (self):
		
		f = open ('cfg.dot', 'w')
		f.write (CFG.dot_string)
		f.close ()

		retcode = subprocess.call(["dot", "-Tps", "-ocfg.ps", "cfg.dot"])
		assert retcode == 0


	# From Cooper/Torczon p457-463
	def build_dominance (self):
		self.build_dominator_sets ()
		self.build_immediate_dominators ()
		self.build_dominance_frontier ()

	def build_dominator_sets (self):

		# Initial condition: entry node dominates itself
		for bb in self.get_bbs ():
			bb.doms = set (self.get_bbs ())

		self.get_entry ().doms = set ([self.get_entry()])



		# Iterate through all the nodes, adding the interesction of the
		# dominators of their predecessors
		reiterate = True
		while reiterate:
			reiterate = False
			for bb in self.get_bbs ():

				if bb.in_degree () == 0:
					continue;

				size = len (bb.doms)

				bb.doms = set([bb]) | reduce (
					lambda local_dom, pred:
						local_dom & pred.doms
					, bb.preds ()
					, set(self.get_bbs ()))

				# solution has changed
				if (size != len (bb.doms)):
					reiterate = True


	def build_immediate_dominators (self):
		for bb in self.get_bbs ():
			bb.idoms = copy.copy (bb.doms)

		# trim to get immediate dominators
		# Not from cooper/torczon - made up myself.
		for bb in self.get_bbs ():
			bb.idoms -= set([bb])

		for bb in self.get_bbs ():
			# If a dominator d1 of n dominates another dominate d2 of n, remove d1.
			for dominator in set(bb.idoms):
				if dominator != bb:
					bb.idoms -= dominator.idoms


		# convert to a list
		for bb in self.get_bbs ():
			bb.idoms = list(bb.idoms)


		# make a graph
		self.D = nx.DiGraph()
		for src in self.get_bbs ():
			for dest in src.idoms:
				self.D.add_edge (dest, src)


			
		
	# The DF of a node n is the set of nodes x, where x is not dominated by n,
	# but where x has a predecessor p which is dominated by n.
	def build_dominance_frontier (self):

		for bb in self.get_bbs ():
			if (bb.in_degree () > 1):
				for pred in bb.preds ():
					runner = pred
					while (runner != bb.get_immediate_dominator ()):
						runner.df.add (bb)
#						print "adding " + str(node) + " to df of " + str(runner) + "\n"
						runner = runner.get_immediate_dominator ()



	def print_dominance_info (self):
		for bb in self.get_bbs ():
			print "Block: ", bb.name
			print "Dominators:", bb.doms
			print "Immediate Dominators:", bb.idoms
			print "Dominance frontiers:", bb.df
			print




	def dump_dom (self):
		nx.to_agraph (self.D).draw ('dominance.ps', prog="dot")




	# Execute each block in turn, calling CALLBACK. CALLBACK should return true
	# if it changed the result for BLOCK.
	def symbolically_execute (self):

		self.def_use_chains = Def_use_chain ()

		# Use the Wegman-Zadeck SCCP algorithm
		self.cfg_wl = CFG_worklist (self.get_entry ())
		self.ssa_wl = SSA_worklist (self.def_use_chains)


		while (len (self.cfg_wl)):

			bb = self.cfg_wl.next()

			# On the first execution, add the successor blocks
			if not self.cfg_wl.has_been_executed (bb):

				self.cfg_wl.mark_executed (bb)
				self.cfg_wl.extend (bb.succs (), "First time successors")

				for stmt in bb.stmts:

					debug ("\n"); debug ("CFG-edge: Executing %s from BB %s" % (stmt, stmt.bb))

					# No point leaving it in. TODO: abstract this
					if stmt in self.ssa_wl:
						self.ssa_wl.remove (stmt)

					changed = False
					for c in self.execution_clients:
						changed |= c.execute_stmt (bb, stmt, self.ssa_wl, self.def_use_chains)

					if changed:
						self.dump_cfg ("After SSA construction in %s\\nBrighter reds come first" % bb, bb)


		# Now do def-use chains
		while (len (self.ssa_wl)):

			stmt = self.ssa_wl.next ()

			debug ("\n"); debug ("SSA-edge: Executing %s from BB %s" % (stmt, stmt.bb))

			changed = False
			for c in self.execution_clients:
				changed |= c.execute_stmt (stmt.bb, stmt, self.ssa_wl, self.def_use_chains)


			if changed:
				self.dump_cfg ("After SSA construction in %s\\nBrighter reds come first" % bb, stmt.bb)



		# We're done. Check its correct.
		for c in self.execution_clients:
			c.check ()



	def add_execution_client (self, client):
		self.execution_clients.append (client)


class Def_use_chain:

	def __init__ (self):
		# Map: var -> stmt
		self.chains = {}

	def update_use (self, stmt, oldvar, newvar):
		if oldvar == newvar:
			return

		varcopy = self.get_suitable_copy (oldvar)
		if varcopy in self.chains:
			debug ("Replace use of %s with %s in %s" % (oldvar, newvar, stmt))
			if stmt in self.chains[varcopy]:
				self.chains[varcopy].remove (stmt)

		self.add_use (stmt, newvar)

	# We copy, because the object is mutable, and we dont want to upset the
	# hashing or we wont find it.
	def get_suitable_copy (self, var):
		varcopy = copy.copy (var)
		varcopy.__hash__ = varcopy.hash_for_immutable_vars
		return varcopy


	def add_use (self, stmt, var):
		varcopy = self.get_suitable_copy (var)
		if varcopy not in self.chains:
			self.chains[varcopy] = set ()
		self.chains[varcopy].add (stmt)

	def get_uses (self, var):

		varcopy = self.get_suitable_copy (var)

		if varcopy in self.chains:
			return self.chains[varcopy]

		return []



class SSA_worklist (list):

	def __init__ (self, def_use_chains):
		self.def_use_chains = def_use_chains

	def add_dominated_uses (self, dominator, var):
		newstmts = self.def_use_chains.get_uses (var)
		dominated = [stmt for stmt in newstmts if stmt.is_dominated_by (dominator)]
		if len (dominated):
			debug ("Adding stmts (%s) for use (%s)" % (dominated, var))
		self.extend (newstmts, "as dominated uses")

	def extend (self, list, why):
		added = []
		for bb in list:
			if self.append (bb):
				added.append (bb)

		if len (added):
			debug ("Added %s (reason: %s)" % (added, why))

	# Dont add blocks already in there
	def append (self, bb):
		already = bb in self

		if not already:
			super (SSA_worklist, self).append (bb)
		
		return not already

	def next (self):
		result = self.pop (0)
		return result




class CFG_worklist(list):

	def __init__ (self, initial = []):
		self.already_executed = set()
		self.append (initial)

	# TODO return blocks before their postdominators
	def next (self):
		result = self.pop (0)
		return result

	def has_been_executed (self, block):
		return block in self.already_executed

	def extend (self, list, why):
		added = []
		for bb in list:
			if self.append (bb):
				added.append (bb)

		if len (added):
			debug ("Added %s (reason: %s)" % (added, why))

	# Dont add blocks already in there
	def append (self, bb):
		already = bb in self

		if not already:
			super (CFG_worklist, self).append (bb)
		
		return not already

	def mark_executed (self, block):
		self.already_executed.add (block)




class SSA_construction:

	def __init__ (self, cfg):
		self.cfg = cfg
		self.versions = {}

	def get_version (self, bb, stmt, var):
#		debug ("Looking for %s in '%s' in %s" % (var, stmt, bb))

		# Special case: Start a phi in its predecessor, or else it may go to the
		# wrong dominator.
		if stmt.__class__ == IR.Phi and stmt.bb == bb and id(stmt.lhs) != id(var):
#			debug ("Special case: phi")
			return self.get_version (stmt.get_pred_for_var (var), None, var)


		if bb == None:
#			debug ("No BB, return 0")
			return 0

		# If stmt was passed, strip the end of the list off (after stmt)
		if stmt == None:
			stmts = copy.copy (bb.stmts)
		else:
			stmts = []
			assert stmt in bb.stmts
			for s in bb.stmts:
				if s == stmt:
					break
				stmts.append (s)

#		debug ("Looking in %s" % stmts)

		# Back through the stmts
		stmts.reverse ()
		for s in stmts:
			for d in s.get_defs ():
				if d.name == var.name and d.in_ssa: # skip over defs not in SSA
#					debug ("Found it")
					return d.version


		# Didnt find it in this block - try the dominator
#		debug ("Didnt find it in %s" % bb)
		return self.get_version (bb.get_immediate_dominator (), None, var)


	# Convert the use to SSA (in place). Update the def_use_chains.
	def set_use_version (self, bb, stmt, use):
		version = self.get_version (bb, stmt, use)
		if use.version != version or not use.in_ssa:
			debug ("Setting use %s to version %s" % (use, version))
			use.set_version (version)


	def execute_stmt (self, bb, stmt, ssa_wl, def_use_chains):

		changed = False

		for use in stmt.get_uses ():
			oldvar = copy.copy (use)
			self.set_use_version (bb, stmt, use)
			def_use_chains.update_use (stmt, oldvar, use)
			changed |= oldvar != use

		# After adding a version, what uses do we need to change? Well,
		# whatever the use is after this point! There are 2 possibilities:
		#
		#		We have added a phi def x_j on a path between a def and use of
		#		x_i, and putting in x_j. So we need to find the uses of x_i and
		#		replace them with x_j.
		#
		#		We have renamed a def x into x_j, so we need to find uses of x
		#		and rename them.
		for d in stmt.get_defs ():
			if not d.in_ssa:
				version = self.cfg.vars[d.name].new_version ()
				debug ("Setting def %s to version %s" % (d, version))
				d.set_version (version)
				self.add_phis_to_df (bb, d.name, ssa_wl)

				# Only add the uses if they are dominated by STMT
				ssa_wl.add_dominated_uses (stmt, d.non_ssa ())
				ssa_wl.add_dominated_uses (stmt, d.with_version (self.get_version (bb, stmt, d)))
				changed = True

		return changed


	def add_phis_to_df (self, bb, varname, ssa_wl):

		# Add phis in their dominance frontiers
		for df in bb.df:
			if df.has_phi (varname):
				continue	

			phi = IR.Phi (varname, df.preds ())
			phi.bb = df
			df.stmts.insert (0, phi)

			ssa_wl.append (phi)

			debug ("Adding phi for %s in %s (df of %s)" % (varname, df, bb))




	def check (self):

		# Check all variables ahve been converted to SSA
		for bb in self.cfg.get_bbs ():
			for stmt in bb.stmts:
				for d in stmt.get_defs ():
					if not d.in_ssa:
						sys.exit ("Def %s not in ssa in %s (bb %s)" % (d, s, bb))

				for u in stmt.get_uses ():
					if not u.in_ssa:
						sys.exit ("Use %s not in ssa in %s (bb %s)" % (u, s, bb))

		# Check the single-assignment property
		seen = {}
		for bb in self.cfg.get_bbs ():
			for stmt in bb.stmts:
				for d in stmt.get_defs ():
					pair = (d.version, d.name)
					if pair in seen:
						sys.exit ("Already seen %s in BB %s (second one in %s)" % (d, bb, seen[pair]))
					seen[pair] = bb


		# Check the dominance property
		for bb in self.cfg.get_bbs ():
			for stmt in bb.stmts:
				for use in stmt.get_uses ():
					version = self.get_version (bb, stmt, use)
					if use.version != version:
						sys.exit ("%s's version should be %s in bb %s" % (use, version, bb))

		
def exit_function ():
	if "cfg" in globals ():
		global cfg
#		cfg.dump_all_vars ()
		cfg.dump_saved_dot ()



atexit.register (exit_function)

cfg = CFG (test1.vars, test1.bbs)
#cfg.dump_dom ()

# Now that we have dominance frontiers, we want to implement the symbolic execution algorithm.

cfg.add_execution_client (SSA_construction (cfg))
#cfg.add_execution_client (SCCP ())
#cfg.add_execution_client (aliasing ())

cfg.symbolically_execute ()


