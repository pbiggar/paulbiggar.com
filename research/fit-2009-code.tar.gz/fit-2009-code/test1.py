from IR import *

vars = set (["a", "b", "c", "d", "i", "x", "y", "z"])

bbs = {
	"entry":
	[
		Goto (0)
	],

	0:
	[
		Copy ("i", "z"),
		Goto (1)
	],

	1:
	[
		Output ("b"),
		Copy ("b", "x"),
		Assign ("a", 5),
		Branch ("a", 2, 3)
	],

	2:
	[
		Assign ("c", 6),
		Copy ("d", "i"),
		Copy ("b", "a"),
		Goto (7)
	],

	3:
	[
		Input ("a"),
		Output ("d"),
		Copy ("d", "y"),
		Branch ("d", 4, 5)
	],

	4:
	[
		Copy ("d", "a"),
		Goto (6)
	],

	5:
	[
		Copy ("c", "d"),
		Goto (6)
	],

	6:
	[
		Copy ("b", "i"),
		Goto (7)
	],

	7:
	[
		Assign ("i", 0),
		Input ("y"),
		Output ("c"),
		Copy ("z", "b"),
		Branch ("a", "exit", 2)
	],

	"exit":
	[
	]
}
