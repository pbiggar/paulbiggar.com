# Statement types are:
#	- Assign: var = value; // VALUE is an int
#  - Copy: var1 = var2;
#  - Input: cin >> var
#  - Output: cout << var
#  - Phi: lhs = PHI (r1, ..., rj)
#  - Nop:  // do nothing
#  - Branch: if (var) ... 
#  - Goto:

# BBs are a list of statements (phis must be first, if present), ending with a Branch or a Goto

import var
import util 

class Stmt:

	# Is SELF dominated by BB
	def is_dominated_by (self, stmt):
		assert isinstance (stmt, Stmt)

		if self == stmt:
			return True

		if self.bb == stmt.bb:
			# Whichever we reach first is the dominator
			for s in self.bb.stmts:
				if s == self:
					return False 
				if s == stmt:
					return True

			assert False # unreachable

		else:
			return self.bb.is_dominated_by (stmt.bb)

	def __repr__ (self):
		return self.__str__ ()



class Nop (Stmt):
	pass

class Assign (Stmt):

	def __init__ (self, lhs, value):
		self.lhs = var.Var(lhs)
		self.value = value

	def __str__ (self):
		return "%s = %s" % (self.lhs, self.value)

	def get_uses (self):
		return []
	
	def get_defs (self):
		return [self.lhs]



class Goto (Stmt):

	def __init__ (self, target):
		self.target = target

	def get_successor_names (self):
		return [self.target]

	def get_defs (self):
		return []

	def get_uses (self):
		return []

	def __str__ (self):
		return "goto %s" % self.target



class Copy (Stmt):

	def __init__ (self, lhs, rhs):
		self.lhs = var.Var(lhs)
		self.rhs = var.Var(rhs)

	def get_defs (self):
		return [self.lhs]

	def get_uses (self):
		return [self.rhs]

	def __str__ (self):
		return "%s = %s" % (self.lhs, self.rhs)
		


class Input (Stmt):

	def __init__ (self, lhs):
		self.lhs = var.Var(lhs)

	def get_defs (self):
		return [self.lhs]

	def get_uses (self):
		return []

	def __str__ (self):
		return "%s = input ()" % (self.lhs)


class Output (Stmt):

	def __init__ (self, rhs):
		self.rhs = var.Var (rhs)

	def get_defs (self):
		return []

	def get_uses (self):
		return [self.rhs]

	def __str__ (self):
		return "output (%s)" % (self.rhs)



class Branch (Stmt):
	
	def __init__ (self, v, target1, target2):
		self.var = var.Var (v)
		self.target1 = target1
		self.target2 = target2

	def get_successor_names (self):
		return [self.target1, self.target2]

	def get_defs (self):
		return []

	def get_uses (self):
		return [self.var]

	def __str__ (self):
		return "if (%s)" % (self.var)

class Phi (Stmt):

	def __init__ (self, lhs, preds):
		assert isinstance (lhs, str)
		self.lhs = var.Var (lhs);
		self.rhss = {}
		for pred in preds:
			self.rhss[pred] = var.Var (lhs)

	def __str__ (self):
		result = "%s <- PHI(" % self.lhs
		for v in self.rhss.values ():
			result += str (v) + ", "

		result += ")"
		return result

	def get_defs (self):
		return [self.lhs]

	def get_uses (self):
		return self.rhss.values ()

	# Remove mapping the 
	def get_pred_for_var (self, v):
		for pred in self.rhss:
			if v == self.rhss[pred]:
				return pred

		assert False






