class Var:
	def __init__ (self, name):
		self.name = name
		self.in_ssa = False
		self.version = 0

	def set_version (self, version):
		self.version = version
		self.in_ssa = True

	def new_version (self):
		self.version += 1
		return self.version

	# Factory
	def non_ssa (self):
		return Var (self.name)

	# Factory
	def with_version (self, version):
		result = Var (self.name)
		result.version = version
		result.in_ssa = True
		return result
		

	def __str__ (self):
		if (self.in_ssa):
			return "%s_%s" % (self.name, self.version)
		else:
			return self.name

	def __eq__ (self, other):
		return str (self) == str (other)

	def __ne__ (self, other):
		return str (self) != str (other)

	def __repr__ (self):
		return self.__str__ ()

	def hash_for_immutable_vars (self):
		return str (self).__hash__ ()
		
