import types
from pprint import *

def dump (obj, ignore = []):
	as_array = convert_to_array (obj, ignore)
	pprint (as_array)

def convert_to_array (obj, ignore):
	# Ignore what we've alrady seen
	if obj in ignore:
		return obj
	else:
		# dont ignore scalars and empty collections
		if obj not in [[], {}, set()] and type(obj) not in [types.IntType, types.StringType]:
			ignore.append (obj)

	# User objects
	if type (obj) is types.InstanceType:
		result = {}
		for field, value in obj.__dict__.iteritems():
			result[field] = convert_to_array (value, ignore)

		return (obj, result)

	# Lists
	elif type (obj) is types.ListType:
		return map (lambda val: convert_to_array (val, ignore), obj)

	elif type (obj) is types.DictType:
		result = {}
		for field, value in obj.iteritems():
			result[field] = convert_to_array (value, ignore)
		return result

	else:
		return obj

def debug (message):
	print "DEBUG: " + message
	pass


