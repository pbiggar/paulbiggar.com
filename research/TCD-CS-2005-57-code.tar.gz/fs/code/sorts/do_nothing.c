void
do_nothing(unsigned int a[], int N)
{
}
